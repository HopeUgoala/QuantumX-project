<html>
  <head>
    <title>On/Off Button</title>
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <div>
      <button class="offButton">
        <span>
          <i class="fa fa-power-off" aria-hidden="true"></i>
        </span>
      </button>
    </div>
  </body>
</html>